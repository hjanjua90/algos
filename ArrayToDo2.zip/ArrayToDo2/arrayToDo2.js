// Given a numerical array, reverse the order of values, in-place. The reversed array should have the same length, with existing elements moved to other indices so that order of elements is reversed. Working 'in-place' means that you cannot use a second 
// array – move values within the array that you are given. As always, do not use built-in array functions such as splice().


// function reverseArray(arr){
//     for (var i = 0; i < arr.length/2; i++){
//         var x = arr[i];
//         arr[i] = arr[arr.length - 1 -i];
//         arr[arr.length - 1 -i] = x;

//     }

// }

// var arr1 = [3,6,9,12,15];
// reverseArray(arr1);
// console.log(arr1);
// resulut1 = [15,12,9,6,3];


// Implement rotateArr(arr, shiftBy) that accepts array and offset. Shift arr's values to the right by that amount. 'Wrap-around' any values that shift off array's end to the other side, so that no data is lost. Operate in-place: given ([1,2,3],1), 
// change the array to [3,1,2]. Don't use built-in functions.
// Second: allow negative shiftBy (shift L, not R).
// Third: minimize memory usage. With no new array, handle arrays/shiftBys in the millions.
// Fourth: minimize the touches of each element.

// function rotateArr(arr, shiftBy){
//     if (shiftBy> 0){
//         // rotate to the rt
//         for (var i = 0; i< shiftBy; i++){
//             var x = arr[arr.length - 1];
//             for (var y = arr.length - 2; y >= 0; y--){
//                 arr[y+1] = arr[y];
//             }
//             arr[0] = x 
//             }
//     }else{
//         // rotate left
//         var numRotations = Math.abs(shiftBy);
//         for (var i = 0; i< numRotations; i++){
//             var x = arr[0];
//             for (var y = 1; y < arr.length; y++){
//                 arr[y-1]= arr[y]
//             }
//             arr[arr.length -1] = x
//         }
        
//     }
    
// }
// var arr1 = [3,6,9,-12,15];
// rotateArr(arr1,-1);
// console.log(arr1);

// Filter Range
// Alan is good at breaking secret codes. One method is to eliminate values that lie outside of a specific known range. Given arr and values min and max, retain only the array values between min and max. Work in-place: return the array you are given, with values in original order. No built-in array functions.
// Max and Min values & no bulit in functions

// function filterRange(arr, minValue, maxValue){
//     var nextIndex = 0;
//     for (var i = 0; i< arr.length; i++){
//         if (arr[i] >= minValue && arr[i] <= maxValue){
//             arr[nextIndex] = arr[i];
//             nextIndex++
//         }
//     }
//     arr.length = nextIndex;
// }

// var arr1 = [4,3,2,6,1,5,8]
// filterRange(arr1,2,5)
// console.log(arr1)



// Concat 
// Replicate JavaScript's concat(). Create a standalone function that accepts two arrays. Return a new array containing the first array's elements, followed by the second array's elements. Do not alter the original arrays. Ex.: arrConcat( ['a','b'], [1,2] ) should return new array ['a','b',1,2].
// 1.Create function that takes two array's elements.
// 2. do not alter orginal array

function concatArrays(arr1, arr2){
    var newArr = [];
    var currentIndex = 0;
    for (var i=0; i < arr2.length; i++){
        newArr[currentIndex] = arr2[i];currentIndex++
    }
    for (var i=0; i < arr1.length; i++){
        newArr[currentIndex] = arr1[i];currentIndex++
    }
    return newArr;
}

var results = concatArrays([2,"Jazlyn", -2], ["Anaahat", 6]);
console.log(results)
