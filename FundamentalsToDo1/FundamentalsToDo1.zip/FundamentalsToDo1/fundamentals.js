var myNumber = 42 
var myName = Harp 
console.log("myNumber")
